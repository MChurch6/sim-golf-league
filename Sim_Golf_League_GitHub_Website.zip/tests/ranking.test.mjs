import test from 'node:test';
import assert from 'node:assert/strict';
import { standings } from '../src/utils.js';
import { demoPlayers, demoRounds } from '../src/data.js';

test('example leaderboard orders qualified best-four totals', () => {
  const results = standings(demoPlayers, demoRounds);
  assert.equal(results[0].name, 'James');
  assert.deepEqual(results[0].bestScores, [43,42,41,39]);
  assert.equal(results[0].bestFour, 165);
  assert.equal(results[0].rank, 1);
  assert.equal(results[1].name, 'Tom');
});

test('extra low scores do not reduce a best-four total', () => {
  const extra = {...demoRounds[0], id:'extra', player_id:demoPlayers[0].id, stableford_points: 0};
  assert.equal(standings(demoPlayers, [...demoRounds,extra])[0].bestFour,165);
});

test('players with fewer than four rounds do not rank', () => {
  const results = standings(demoPlayers,demoRounds);
  assert.equal(results.find(x=>x.name==='Chris').rank,null);
  assert.equal(results.find(x=>x.name==='Jordan').rank,null);
});

test('identical best-fours share a rank and the next golfer is third', () => {
  const players=['A','B','C'].map((name,i)=>({id:name,name,display_order:i+1}));
  const scores={A:[40,39,38,37],B:[40,39,38,37],C:[40,39,38,36]};
  const rounds=Object.entries(scores).flatMap(([player_id,pts])=>pts.map((stableford_points,i)=>({id:player_id+i,player_id,stableford_points})));
  const results=standings(players,rounds);
  assert.deepEqual(results.map(x=>x.rank),[1,1,3]);
});
