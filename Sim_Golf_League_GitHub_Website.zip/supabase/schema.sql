-- THE CLUBHOUSE / Sim Golf League
-- Paste the entire file into Supabase SQL Editor, then Run.
-- The public may read league scores. ONLY authenticated accounts explicitly
-- added to league_admins can create, update or delete players/rounds.
-- Never put a service_role key in a web app or GitHub Actions build.

create extension if not exists pgcrypto;

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  display_order smallint not null unique check (display_order between 1 and 8),
  name text not null unique check (length(trim(name)) between 1 and 50),
  created_at timestamptz not null default now()
);

create table if not exists public.rounds (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.players(id) on delete restrict,
  played_on date not null,
  course text not null check (length(trim(course)) between 1 and 100),
  difficulty_rating numeric(5,1) check (difficulty_rating between 0 and 200),
  handicap_used numeric(4,1) not null check (handicap_used between -20 and 60),
  stableford_points integer not null check (stableford_points between 0 and 80),
  notes text not null default '' check (length(notes) <= 500),
  created_at timestamptz not null default now()
);
create index if not exists rounds_player_date_idx on public.rounds (player_id,played_on desc);
create index if not exists rounds_date_idx on public.rounds (played_on desc);

create table if not exists public.league_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.players enable row level security;
alter table public.rounds enable row level security;
alter table public.league_admins enable row level security;

-- Security-definer function checks the private admin list. No one can modify
-- this list via the public API. A signed-in visitor is not automatically admin.
create or replace function public.is_league_admin()
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.league_admins la
    where la.user_id = (select auth.uid())
  );
$$;
revoke all on function public.is_league_admin() from public, anon;
grant execute on function public.is_league_admin() to authenticated;

-- Ensure no pre-existing policies with the same name block repeat setup.
drop policy if exists "Anyone can view players" on public.players;
drop policy if exists "Admin can add players" on public.players;
drop policy if exists "Admin can change players" on public.players;
drop policy if exists "Admin can delete players" on public.players;
drop policy if exists "Anyone can view rounds" on public.rounds;
drop policy if exists "Admin can add rounds" on public.rounds;
drop policy if exists "Admin can change rounds" on public.rounds;
drop policy if exists "Admin can delete rounds" on public.rounds;

create policy "Anyone can view players" on public.players
  for select to anon, authenticated using (true);
create policy "Admin can add players" on public.players
  for insert to authenticated with check ((select public.is_league_admin()));
create policy "Admin can change players" on public.players
  for update to authenticated using ((select public.is_league_admin())) with check ((select public.is_league_admin()));
create policy "Admin can delete players" on public.players
  for delete to authenticated using ((select public.is_league_admin()));

create policy "Anyone can view rounds" on public.rounds
  for select to anon, authenticated using (true);
create policy "Admin can add rounds" on public.rounds
  for insert to authenticated with check ((select public.is_league_admin()));
create policy "Admin can change rounds" on public.rounds
  for update to authenticated using ((select public.is_league_admin())) with check ((select public.is_league_admin()));
create policy "Admin can delete rounds" on public.rounds
  for delete to authenticated using ((select public.is_league_admin()));

-- Public API privileges, further restricted by the RLS policies above.
grant select on public.players, public.rounds to anon, authenticated;
grant insert, update, delete on public.players, public.rounds to authenticated;
revoke all on public.league_admins from anon, authenticated;

-- Create exactly eight player slots once (rename them in the admin UI).
insert into public.players (display_order, name) values
  (1, 'Player 1'),(2, 'Player 2'),(3, 'Player 3'),(4, 'Player 4'),
  (5, 'Player 5'),(6, 'Player 6'),(7, 'Player 7'),(8, 'Player 8')
on conflict (display_order) do nothing;

-- Optional live updates. Polling also refreshes the site every 60 seconds.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname='public' and tablename='players'
  ) then alter publication supabase_realtime add table public.players; end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname='public' and tablename='rounds'
  ) then alter publication supabase_realtime add table public.rounds; end if;
end $$;

-- AFTER creating YOUR auth user in Supabase > Authentication > Users,
-- run a separate query with your actual email address to make you admin:
-- insert into public.league_admins(user_id)
-- select id from auth.users where email = 'YOUR_ADMIN_EMAIL@EXAMPLE.COM'
-- on conflict (user_id) do nothing;
-- Check that it inserted exactly one row; if zero, create the Auth user first.
