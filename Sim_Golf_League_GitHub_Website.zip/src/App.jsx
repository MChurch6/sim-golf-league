import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity, ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, Award,
  BarChart3, CalendarDays, Check, CheckCircle2, ChevronDown, ChevronRight,
  CircleHelp, Clock3, Cloud, Download, Flag, FlagTriangleRight, Gauge,
  Globe2, LayoutDashboard, LockKeyhole, LogIn, LogOut, MapPin, Menu,
  Medal, MoreHorizontal, Pencil, Plus, RefreshCcw, Search, Settings2,
  ShieldCheck, Target, Trash2, TrendingUp, Trophy, Users, X,
} from 'lucide-react';
import { LEAGUE } from './config.js';
import { demoPlayers, demoRounds } from './data.js';
import { supabase, isConfigured } from './supabase.js';
import { formatDate, initials, number, standings, toCSV } from './utils.js';

const COLORS = ['#c8f17a','#8eceb2','#ffb986','#a3bbf8','#efb4df','#d7c59e','#9bd4dd','#e0ca87'];
const NAV = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  { id: 'rounds', label: 'Round history', icon: CalendarDays },
  { id: 'players', label: 'Players', icon: Users },
  { id: 'courses', label: 'Courses', icon: Flag },
];
const today = () => new Date().toISOString().slice(0, 10);

function classNames(...names) { return names.filter(Boolean).join(' '); }
function IconButton({ icon: Icon, label, onClick, className = '' }) {
  return <button className={classNames('icon-button', className)} type="button" onClick={onClick} aria-label={label} title={label}><Icon size={18}/></button>;
}
function Avatar({ player, size = 'md' }) {
  const color = COLORS[((player?.display_order || 1) - 1) % COLORS.length];
  return <span className={classNames('avatar', `avatar-${size}`)} style={{'--avatar-color':color}}>{initials(player?.name)}</span>;
}
function ScoreChips({ scores, ghost = false }) {
  return <div className="score-chips">{Array.from({ length: 4 }, (_, i) => scores[i] != null
    ? <span className="score-chip" key={i}>{scores[i]}</span>
    : <span key={i} className="score-chip empty">—</span>)}{ghost && <span className="visually-hidden">Qualification not yet complete</span>}</div>;
}
function StatusPill({ qualified, played }) {
  return qualified ? <span className="status-pill qualified"><span className="status-dot"/>Qualified</span> : <span className="status-pill provisional"><span className="status-dot"/>{played === 0 ? 'No rounds' : `${played}/4 played`}</span>;
}
function Modal({ title, kicker, children, onClose, narrow = false }) {
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);
  return <div className="modal-backdrop" onMouseDown={e => { if(e.target === e.currentTarget) onClose(); }}>
    <div className={classNames('modal', narrow && 'modal-narrow')} role="dialog" aria-modal="true" aria-label={title}>
      <div className="modal-heading"><div><span className="eyebrow">{kicker}</span><h2>{title}</h2></div><IconButton icon={X} label="Close" onClick={onClose}/></div>
      {children}
    </div>
  </div>;
}
function Toast({ message, onClose }) {
  if (!message) return null;
  return <div className="toast" role="status"><CheckCircle2 size={17}/><span>{message}</span><button type="button" onClick={onClose} aria-label="Dismiss"><X size={15}/></button></div>;
}
function ScoreGraph({ rows }) {
  const points = [...rows].sort((a,b) => a.played_on.localeCompare(b.played_on)).slice(-12);
  if (!points.length) return <div className="graph-empty">No scores recorded yet</div>;
  const w = 620, h = 160, pad = 16;
  const min = Math.max(0, Math.min(25, ...points.map(x=>Number(x.stableford_points))) - 5);
  const max = Math.max(45, ...points.map(x=>Number(x.stableford_points))) + 4;
  const getX = i => pad + i * ((w-2*pad) / Math.max(1,points.length - 1));
  const getY = v => h - pad - ((v-min)/(max-min))*(h-2*pad);
  const path = points.map((p,i) => `${i?'L':'M'} ${getX(i).toFixed(1)} ${getY(Number(p.stableford_points)).toFixed(1)}`).join(' ');
  const area = `${path} L ${getX(points.length-1)} ${h-pad} L ${pad} ${h-pad} Z`;
  return <div className="graph-wrap"><svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" role="img" aria-label="Stableford scores over time">
    <defs><linearGradient id="graphFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#bcec76" stopOpacity=".23"/><stop offset="100%" stopColor="#bcec76" stopOpacity="0"/></linearGradient></defs>
    {[0.25,.5,.75].map(p=><line key={p} x1="0" x2={w} y1={h*p} y2={h*p} stroke="#ffffff" strokeOpacity=".08" strokeDasharray="3 8"/>)}
    <path d={area} fill="url(#graphFill)"/><path d={path} fill="none" stroke="#c4ec83" strokeWidth="2.7" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke"/>
    {points.map((p,i)=><circle key={p.id} cx={getX(i)} cy={getY(Number(p.stableford_points))} r="3.7" fill="#c4ec83" stroke="#12201b" strokeWidth="2"><title>{formatDate(p.played_on)}: {p.stableford_points} points</title></circle>)}
  </svg><div className="graph-axis"><span>{formatDate(points[0]?.played_on)}</span><span>{formatDate(points[points.length-1]?.played_on)}</span></div></div>;
}
function CourseArtwork() {
  return <div className="golf-art" aria-hidden="true"><div className="art-glow"/><svg viewBox="0 0 600 260" fill="none" preserveAspectRatio="xMidYMid meet">
    <defs><linearGradient id="fairway" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#5b8e50"/><stop offset="1" stopColor="#2e5540"/></linearGradient><linearGradient id="hills" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#3a674a"/><stop offset="1" stopColor="#214b3c"/></linearGradient></defs>
    <ellipse cx="320" cy="222" rx="230" ry="46" fill="#172b25" opacity=".35"/>
    <path d="M38 238C141 167 243 198 310 143C377 94 457 124 576 66V260H38Z" fill="#295c42"/>
    <path d="M90 260C194 177 296 202 353 155C414 106 492 124 600 84V260H90Z" fill="url(#hills)"/>
    <path d="M170 260C269 211 306 212 383 166C444 129 512 143 600 123V260H170Z" fill="url(#fairway)"/>
    <path d="M274 250C344 211 394 191 435 178C484 160 533 171 595 151" stroke="#7cb16a" strokeWidth="25" opacity=".24"/>
    <ellipse cx="444" cy="167" rx="48" ry="12" fill="#7bb37c"/>
    <ellipse cx="462" cy="166" rx="10" ry="3.5" fill="#10241b"/>
    <path d="M460 166V54" stroke="#e8f4cd" strokeWidth="2.8"/>
    <path d="M462 56L516 70L462 87V56Z" fill="#c6ef7b"/>
    <path d="M140 246C157 225 178 219 197 211" stroke="#91bd7d" strokeWidth="1.5" strokeDasharray="4 7" opacity=".55"/>
    <circle cx="170" cy="210" r="12" fill="#f9faf2"/><circle cx="167" cy="207" r="1.3" fill="#bbc3b9"/><circle cx="174" cy="213" r="1.2" fill="#bbc3b9"/><circle cx="175" cy="206" r="1" fill="#bbc3b9"/>
    <path d="M162 218C185 221 201 225 228 230" stroke="#172e25" strokeOpacity=".25" strokeWidth="9" strokeLinecap="round"/>
  </svg><div className="art-caption"><span className="art-caption-line"/>BUILT FOR THE LOVE OF THE GAME</div></div>;
}

function Leaderboard({ rows, openPlayer, compact = false }) {
  const shown = compact ? rows.slice(0, 5) : rows;
  return <div className="leaderboard-wrap"><table className="leaderboard-table"><thead><tr><th className="pos-col">POS</th><th>PLAYER</th><th className="hide-mobile">STATUS</th><th className="number-col hide-sm">ROUNDS</th><th className="best-col hide-mobile">BEST FOUR ROUNDS</th><th className="number-col">TOTAL</th><th className="last-col"/></tr></thead>
    <tbody>{shown.map((p, i) => <tr key={p.id} onClick={()=>openPlayer(p.id)} tabIndex={0} onKeyDown={e=>{if(e.key==='Enter')openPlayer(p.id)}} className={classNames('clickable-row',p.qualified && p.rank === 1 && 'leader-row')}>
      <td className="pos-col"><span className={classNames('rank-number',p.rank === 1 && 'first')}>{p.rank ? String(p.rank).padStart(2,'0') : '—'}</span></td>
      <td><div className="player-cell"><Avatar player={p}/><div><strong>{p.name}</strong><span className="mobile-sub">{p.played} rounds · {p.qualified ? 'Qualified' : `${p.played}/4 to qualify`}</span></div>{p.rank===1 && <Trophy className="champ-icon" size={15}/>}</div></td>
      <td className="hide-mobile"><StatusPill qualified={p.qualified} played={p.played}/></td>
      <td className="number-col hide-sm subtle-number">{p.played}</td>
      <td className="best-col hide-mobile"><ScoreChips scores={p.bestScores}/></td>
      <td className="number-col"><span className={classNames('total-points',!p.qualified && 'muted-total')}>{p.bestFour || '—'}</span><span className="pts-label"> PTS</span></td>
      <td className="last-col"><ChevronRight size={17}/></td>
    </tr>)}</tbody>
  </table>{rows.length===0 && <div className="empty-state">No players have been added yet.</div>}</div>;
}
function StatCard({ label, value, meta, icon: Icon, accent = false }) {
  return <div className={classNames('stat-card', accent && 'accent-card')}><div className="stat-top"><span>{label}</span><span className="stat-icon"><Icon size={17}/></span></div><div className="stat-value">{value}</div><div className="stat-foot">{meta}</div></div>;
}
function RoundTable({ rounds, players, isAdmin, onEdit, onDelete, compact = false }) {
  const names = new Map(players.map(p=>[p.id,p]));
  const shown = compact ? rounds.slice(0,5) : rounds;
  return <div className="table-scroll"><table className="rounds-table"><thead><tr><th>PLAYER</th><th>COURSE</th><th className="hide-mobile">DATE</th><th className="hide-sm">HCP</th><th className="hide-sm">RATING</th><th className="text-right">POINTS</th>{isAdmin && <th className="text-right">MANAGE</th>}</tr></thead>
    <tbody>{shown.map(r=>{
      const p=names.get(r.player_id);
      return <tr key={r.id}><td><div className="recent-player"><Avatar player={p} size="sm"/><span>{p?.name||'Unknown'}</span></div></td>
        <td><div className="course-cell"><strong>{r.course}</strong><span className="mobile-sub">{formatDate(r.played_on)}</span></div></td>
        <td className="hide-mobile muted">{formatDate(r.played_on)}</td><td className="hide-sm muted">{number(r.handicap_used)}</td><td className="hide-sm muted">{r.difficulty_rating==null?'—':number(r.difficulty_rating)}</td>
        <td className="text-right"><span className="points-box">{r.stableford_points}</span></td>
        {isAdmin && <td className="text-right"><div className="row-actions"><IconButton icon={Pencil} label="Edit round" onClick={()=>onEdit(r)}/><IconButton icon={Trash2} label="Delete round" onClick={()=>onDelete(r)}/></div></td>}
      </tr>})}</tbody></table>
    {shown.length===0 && <div className="empty-state">No rounds to show yet. Scores will appear here after they're recorded.</div>}</div>;
}
function Intro({ eyebrow, title, description, action }) {
  return <div className="page-intro"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div>{action}</div>;
}
function AuthDialog({ close, notify }) {
  const [email,setEmail]=useState('');const [password,setPassword]=useState('');const [busy,setBusy]=useState(false);const [error,setError]=useState('');
  const login=async(e)=>{e.preventDefault();setBusy(true);setError('');try{const {error}=await supabase.auth.signInWithPassword({email:email.trim(),password});if(error)throw error;notify('Signed in. Checking admin permissions…');close();}catch(err){setError(err.message);}finally{setBusy(false)}};
  return <Modal title="Admin sign in" kicker="RESTRICTED ACCESS" onClose={close} narrow><p className="modal-description">Only the league administrator can add, edit or remove scores. Visitors can view everything without signing in.</p><form onSubmit={login} className="form-grid"><label className="field full"><span>Email address</span><input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email"/></label><label className="field full"><span>Password</span><input required type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Your Supabase password" autoComplete="current-password"/></label>{error&&<div className="form-error">{error}</div>}<button disabled={busy} className="button button-primary full" type="submit"><LockKeyhole size={16}/>{busy?'Signing in…':'Sign in securely'}<ArrowRight size={16}/></button></form><div className="modal-note"><ShieldCheck size={17}/> Access is enforced by database security rules, not just hidden buttons.</div></Modal>;
}
function SetupDialog({ close }) {
  return <Modal title="Finish connecting the site" kicker="PREVIEW MODE" onClose={close} narrow><p className="modal-description">This is the fully interactive front end, displaying clearly labelled example scores. To make changes appear for everyone, connect a Supabase database and publish the GitHub Pages build.</p><div className="setup-list"><div><span>01</span><p>Create a Supabase project and run <code>supabase/schema.sql</code>.</p></div><div><span>02</span><p>Make yourself an admin in Supabase Authentication and add your account to <code>league_admins</code>.</p></div><div><span>03</span><p>Set the two public Supabase environment variables in your GitHub repository.</p></div></div><button className="button button-primary full" onClick={close}>Got it <ArrowRight size={16}/></button></Modal>;
}
const blankRound = (players) => ({ id:null,player_id:players[0]?.id||'',played_on:today(),course:'',difficulty_rating:'',handicap_used:'',stableford_points:'',notes:'' });
function RoundDialog({ close, players, original, save }) {
  const [form,setForm] = useState(original ? {
    ...original, difficulty_rating:original.difficulty_rating ?? '', handicap_used:original.handicap_used ?? '', notes:original.notes || ''
  } : blankRound(players));
  const [busy,setBusy]=useState(false); const [error,setError]=useState('');
  const update=(field,value)=>setForm(f=>({...f,[field]:value}));
  const submit=async(e)=>{e.preventDefault();setError('');setBusy(true);
    try {
      const data={
        player_id:form.player_id, played_on:form.played_on,
        course:form.course.trim(), difficulty_rating:form.difficulty_rating===''?null:Number(form.difficulty_rating),
        handicap_used:Number(form.handicap_used),stableford_points:Number(form.stableford_points), notes:form.notes.trim()
      };
      if(!data.player_id || !data.played_on || !data.course)throw Error('Please complete all required fields.');
      if(!Number.isFinite(data.handicap_used)||data.handicap_used < -20||data.handicap_used > 60)throw Error('Handicap must be between -20 and 60.');
      if(!Number.isInteger(data.stableford_points)||data.stableford_points<0||data.stableford_points>80)throw Error('Stableford points must be a whole number from 0 to 80.');
      if(data.difficulty_rating!==null && (data.difficulty_rating<0||data.difficulty_rating>200))throw Error('Difficulty rating must be between 0 and 200.');
      await save(data,original?.id);
      close();
    } catch(err){setError(err.message);}finally{setBusy(false)};
  };
  return <Modal title={original?'Edit round':'Add a new round'} kicker={original?'UPDATE A SCORE':'ADMIN · SCORE ENTRY'} onClose={close}>
    <p className="modal-description">All rounds are recorded. The highest four Stableford scores per player are counted automatically.</p>
    <form className="form-grid" onSubmit={submit}>
      <label className="field"><span>Player <b>*</b></span><select required value={form.player_id} onChange={e=>update('player_id',e.target.value)}>{players.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
      <label className="field"><span>Date played <b>*</b></span><input type="date" required value={form.played_on} onChange={e=>update('played_on',e.target.value)}/></label>
      <label className="field full"><span>Course <b>*</b></span><input placeholder="e.g. St Andrews – Old Course" maxLength={100} required value={form.course} onChange={e=>update('course',e.target.value)}/></label>
      <label className="field"><span>Handicap used <b>*</b></span><input type="number" inputMode="decimal" min="-20" max="60" step="0.1" required placeholder="e.g. 14.2" value={form.handicap_used} onChange={e=>update('handicap_used',e.target.value)}/></label>
      <label className="field"><span>Course difficulty rating</span><input type="number" inputMode="decimal" min="0" max="200" step="0.1" placeholder="e.g. 72.4" value={form.difficulty_rating} onChange={e=>update('difficulty_rating',e.target.value)}/></label>
      <label className="field full"><span>Stableford points <b>*</b></span><input className="big-score-input" type="number" inputMode="numeric" min="0" max="80" step="1" placeholder="e.g. 39" required value={form.stableford_points} onChange={e=>update('stableford_points',e.target.value)}/></label>
      <label className="field full"><span>Notes <span className="optional">(optional)</span></span><textarea rows={2} maxLength={500} placeholder="Great round, new personal best…" value={form.notes} onChange={e=>update('notes',e.target.value)}/></label>
      <div className="hint full"><CircleHelp size={16}/> Difficulty rating is tracked but does not modify the Stableford score.</div>
      {error&&<div className="form-error full">{error}</div>}
      <div className="modal-actions full"><button className="button button-ghost" type="button" onClick={close}>Cancel</button><button disabled={busy} className="button button-primary" type="submit"><Check size={17}/>{busy?'Saving…':original?'Save changes':'Save round'}</button></div>
    </form>
  </Modal>;
}
function PlayerDialog({ player, close, save }) {
  const [name,setName]=useState(player.name); const [busy,setBusy]=useState(false); const [error,setError]=useState('');
  const submit=async(e)=>{e.preventDefault();setBusy(true);setError('');try{if(!name.trim())throw Error('Enter a name.');await save(player.id,name.trim());close();}catch(err){setError(err.message);}finally{setBusy(false)}};
  return <Modal title="Edit player" kicker={`PLAYER SLOT ${player.display_order}`} onClose={close} narrow><form onSubmit={submit} className="form-grid"><label className="field full"><span>Player name</span><input autoFocus maxLength={50} value={name} onChange={e=>setName(e.target.value)} required/></label>{error&&<div className="form-error full">{error}</div>}<button className="button button-primary full" type="submit" disabled={busy}>{busy?'Saving…':'Save player name'}<Check size={17}/></button></form></Modal>;
}

export default function App() {
  const [page,setPage]=useState('overview'); const [selectedPlayer,setSelectedPlayer]=useState(null);
  const [players,setPlayers]=useState(isConfigured?[]:demoPlayers);
  const [rounds,setRounds]=useState(isConfigured?[]:demoRounds);
  const [loading,setLoading]=useState(isConfigured); const [dataError,setDataError]=useState('');
  const [authUser,setAuthUser]=useState(null);const [isAdmin,setIsAdmin]=useState(false);
  const [dialog,setDialog]=useState(null);
  const [editingRound,setEditingRound]=useState(null);const [editingPlayer,setEditingPlayer]=useState(null);
  const [toast,setToast]=useState('');const [menuOpen,setMenuOpen]=useState(false);
  const [search,setSearch]=useState('');const [filterPlayer,setFilterPlayer]=useState('all');

  const notify=(msg)=>{setToast(msg);window.setTimeout(()=>setToast(''),4500)};
  const reload=useCallback(async()=>{
    if(!supabase)return;
    setDataError('');
    try{
      const {data:p,error:pe}=await supabase.from('players').select('*').order('display_order');
      if(pe)throw pe;
      const all=[];let start=0;const chunk=750;
      for(;;){
        const {data:r,error:re}=await supabase.from('rounds').select('*').order('played_on',{ascending:false}).order('id',{ascending:false}).range(start,start+chunk-1);
        if(re)throw re;
        all.push(...(r||[]));
        if(!r||r.length<chunk)break;
        start+=chunk;
      }
      setPlayers(p||[]);setRounds(all);
    }catch(err){setDataError(err.message||'Could not load scores.');}
    finally{setLoading(false)};
  },[]);
  useEffect(()=>{
    if(!supabase)return;
    reload();
    const updateAdmin=async(user)=>{
      setAuthUser(user||null);
      if(!user){setIsAdmin(false);return;}
      const {data,error}=await supabase.rpc('is_league_admin');
      setIsAdmin(!error&&data===true);
    };
    supabase.auth.getUser().then(({data})=>updateAdmin(data.user)).catch(()=>setIsAdmin(false));
    const {data:sub}=supabase.auth.onAuthStateChange((_event,session)=>{
      // Defer the database query until the auth callback returns.
      window.setTimeout(()=>updateAdmin(session?.user||null),0);
    });
    const channel=supabase.channel('public-golf-league')
      .on('postgres_changes',{event:'*',schema:'public',table:'players'},reload)
      .on('postgres_changes',{event:'*',schema:'public',table:'rounds'},reload).subscribe();
    const refresh=window.setInterval(reload,60000);
    return ()=>{sub.subscription.unsubscribe();supabase.removeChannel(channel);window.clearInterval(refresh)};
  },[reload]);

  const ranking=useMemo(()=>standings(players,rounds),[players,rounds]);
  const leader=ranking.find(p=>p.qualified);
  const bestScore=rounds.length?Math.max(...rounds.map(r=>Number(r.stableford_points))):null;
  const courses=useMemo(()=>{
    const groups=new Map();
    rounds.forEach(r=>{
      const key=r.course.trim().toLowerCase(); const current=groups.get(key)||{name:r.course,count:0,sum:0,ratingSum:0,ratingCount:0,topScore:0};
      current.count++;current.sum+=Number(r.stableford_points);current.topScore=Math.max(current.topScore,Number(r.stableford_points));
      if(r.difficulty_rating!=null){current.ratingSum+=Number(r.difficulty_rating);current.ratingCount++;}
      groups.set(key,current);
    });
    return [...groups.values()].sort((a,b)=>b.count-a.count);
  },[rounds]);
  const namedRounds=useMemo(()=>rounds.map(r=>({...r,playerName:players.find(p=>p.id===r.player_id)?.name||'Unknown'})),[rounds,players]);
  const filteredRounds=useMemo(()=>namedRounds.filter(r=>{
    const q=search.toLowerCase();return (filterPlayer==='all'||r.player_id===filterPlayer)&&(!q||`${r.playerName} ${r.course} ${r.played_on}`.toLowerCase().includes(q));
  }),[namedRounds,search,filterPlayer]);
  const viewPlayer=ranking.find(p=>p.id===selectedPlayer);

  const navigate=(id)=>{setPage(id);setSelectedPlayer(null);setMenuOpen(false);window.scrollTo({top:0,behavior:'smooth'});};
  const openPlayer=(id)=>{setSelectedPlayer(id);setPage('player-detail');window.scrollTo({top:0,behavior:'smooth'});};
  const openAdmin=()=>{if(!isConfigured){setDialog('setup');return;}if(isAdmin){setEditingRound(null);setDialog('round');return;}if(!authUser){setDialog('auth');return;}notify('Signed in, but this account has read-only access.');};
  const saveRound=async(data,id)=>{
    if(!isAdmin)throw Error('Admin permissions required.');
    const result=id ? await supabase.from('rounds').update(data).eq('id',id) : await supabase.from('rounds').insert(data);
    if(result.error)throw result.error;
    await reload();notify(id?'Round updated successfully.':'Round added to the league.');
  };
  const deleteRound=async(r)=>{
    if(!isAdmin)return;
    const name=players.find(p=>p.id===r.player_id)?.name||'this player';
    if(!window.confirm(`Permanently delete ${name}'s ${r.stableford_points}-point round at ${r.course}?`))return;
    const {error}=await supabase.from('rounds').delete().eq('id',r.id);
    if(error){notify(`Could not delete: ${error.message}`);return;}
    await reload();notify('Round deleted.');
  };
  const savePlayer=async(id,name)=>{
    if(!isAdmin)throw Error('Admin permissions required.');
    const {error}=await supabase.from('players').update({name}).eq('id',id);
    if(error)throw error;
    await reload();notify('Player name updated.');
  };
  const exportRounds=()=>{
    const blob=new Blob([toCSV(namedRounds)],{type:'text/csv;charset=utf-8'});
    const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='sim-golf-league-rounds.csv';link.click();URL.revokeObjectURL(link.href);
  };
  const share=async()=>{
    try{await navigator.clipboard.writeText(window.location.href);notify('Website link copied.');}
    catch {notify('Copy the URL from your browser address bar to share.');}
  };
  const signout=async()=>{await supabase.auth.signOut();setIsAdmin(false);setAuthUser(null);notify('Signed out.');};

  return <div className="app-shell">
    <aside className={classNames('sidebar',menuOpen&&'sidebar-open')}>
      <button className="brand" type="button" onClick={()=>navigate('overview')}>
        <span className="brand-mark"><FlagTriangleRight size={23} strokeWidth={2.7}/></span>
        <span><strong>{LEAGUE.name}</strong><small>SIM GOLF LEAGUE</small></span>
      </button>
      <div className="sidebar-divider"/>
      <div className="side-caption">THE LEAGUE</div>
      <nav className="sidebar-nav">{NAV.map(({id,label,icon:Icon})=><button type="button" className={classNames('nav-item',page===id||(page==='player-detail'&&id==='players')?'active':'')} key={id} onClick={()=>navigate(id)}><Icon size={18}/><span>{label}</span>{id==='leaderboard'&&<span className="nav-count">{LEAGUE.maxPlayers}</span>}</button>)}</nav>
      <div className="sidebar-divider sidebar-divider-secondary"/>
      <div className="side-caption">MORE</div>
      <nav className="sidebar-nav"><button className={classNames('nav-item',page==='rules'&&'active')} onClick={()=>navigate('rules')}><CircleHelp size={18}/><span>League rules</span></button></nav>
      <div className="sidebar-spacer"/>
      <div className="side-promo"><div className="promo-badge"><Target size={17}/></div><div className="promo-title">EVERY SHOT<br/>COUNTS.</div><p>Play when you want. Your best four rounds define your season.</p><button onClick={()=>navigate('rules')}>How it works <ArrowUpRight size={14}/></button></div>
      <div className="sidebar-user"><span className="side-user-icon"><ShieldCheck size={17}/></span><span><strong>{isAdmin?'League admin':'Public viewing'}</strong><small>{isAdmin?'Score editing enabled':'Read-only access'}</small></span><span className="live-dot"/></div>
    </aside>
    {menuOpen&&<button className="nav-backdrop" aria-label="Close navigation" onClick={()=>setMenuOpen(false)}/>}
    <div className="main-shell">
      <header className="topbar"><div className="topbar-left"><IconButton className="menu-trigger" icon={Menu} label="Open menu" onClick={()=>setMenuOpen(!menuOpen)}/><span className="topbar-crumb">THE CLUBHOUSE <ChevronRight size={13}/> <strong>{page==='player-detail'?'PLAYER PROFILE':page.toUpperCase()}</strong></span></div><div className="topbar-right"><span className="online-badge"><span/> {isConfigured?'LEAGUE LIVE':'DEMO PREVIEW'}</span><IconButton icon={RefreshCcw} label="Refresh scores" onClick={()=>{if(isConfigured)reload();else notify('Preview data is already up to date.');}}/><button type="button" className="share-button" onClick={share}><Globe2 size={16}/> Share <span>site</span></button>{isAdmin?<button className="button button-primary top-admin" onClick={openAdmin}><Plus size={17}/> Add round</button>:<button className="admin-login" onClick={openAdmin}><LockKeyhole size={16}/> Admin <span>login</span></button>}{authUser&&<IconButton icon={LogOut} label="Sign out" onClick={signout}/>}</div></header>
      <main className="content">
        {!isConfigured&&<div className="demo-banner"><span className="demo-banner-tag">PREVIEW MODE</span><span>Showing example scores. Connect Supabase to publish your real league data.</span><button onClick={()=>setDialog('setup')}>Setup guide <ArrowUpRight size={14}/></button></div>}
        {dataError&&<div className="error-banner"><CircleHelp size={16}/>{dataError}<button onClick={reload}>Try again</button></div>}
        {loading?<div className="loading-state"><span className="loading-spinner"/> Loading league scores…</div>:<>
        {page==='overview'&&<>
          <section className="hero-card"><div className="hero-copy"><div className="hero-eyebrow"><span className="hero-line"/> {LEAGUE.season} <span className="small-star">✳</span> BEST 4 FORMAT</div><h1>YOUR ROUND.<br/><em>YOUR RULES.</em></h1><p>{LEAGUE.description}<br/>One leaderboard. Zero weekly commitments.</p><div className="hero-actions"><button className="button hero-main-button" onClick={()=>navigate('leaderboard')}>View the standings <ArrowUpRight size={17}/></button><button className="hero-text-button" onClick={()=>navigate('rules')}>The format <ArrowRight size={17}/></button></div></div><CourseArtwork/><span className="hero-corner">EST. 2026 · ALWAYS OPEN</span></section>
          <div className="stats-grid"><StatCard label="LEAGUE LEADER" value={leader?.name||'—'} meta={leader?`${leader.bestFour} points from best four`:'No qualified players yet'} icon={Trophy} accent/><StatCard label="TOTAL ROUNDS" value={rounds.length} meta="Across the whole league" icon={Target}/><StatCard label="COURSES PLAYED" value={courses.length} meta="Unique courses on record" icon={Flag}/><StatCard label="TOP SINGLE ROUND" value={bestScore??'—'} meta="Stableford points" icon={TrendingUp}/></div>
          <div className="section-grid"><section className="panel standings-panel"><div className="panel-header"><div><span className="eyebrow">THE MAIN EVENT</span><h2>Live standings</h2></div><button className="text-link" onClick={()=>navigate('leaderboard')}>Full leaderboard <ArrowUpRight size={16}/></button></div><Leaderboard rows={ranking} compact openPlayer={openPlayer}/><div className="panel-footer"><ShieldCheck size={15}/> Best 4 rounds count · Minimum 4 to qualify</div></section>
            <section className="panel side-panel"><div className="panel-header"><div><span className="eyebrow">AT A GLANCE</span><h2>League pulse</h2></div><Activity size={18} className="muted-icon"/></div><div className="side-feature"><span className="side-feature-kicker">THE FRONT RUNNER</span><div className="side-feature-name">{leader?.name||'Waiting for rounds'}</div><div className="side-feature-points">{leader?.bestFour??'—'} <span>POINTS</span></div><span className="side-feature-rule"/><div className="side-feature-bottom"><span>Best-four total</span><Trophy size={22}/></div></div><div className="micro-heading">QUALIFICATION PROGRESS</div><div className="qual-list">{ranking.slice(0,4).map(p=><div className="qual-item" key={p.id}><div className="qual-label"><span>{p.name}</span><span>{Math.min(4,p.played)}/4</span></div><div className="progress-track"><span style={{width:`${Math.min(100,p.played/4*100)}%`}}/></div></div>)}</div></section></div>
          <section className="panel recent-panel"><div className="panel-header"><div><span className="eyebrow">FROM THE SIM</span><h2>Latest rounds</h2></div><button className="text-link" onClick={()=>navigate('rounds')}>All rounds <ArrowUpRight size={16}/></button></div><RoundTable rounds={rounds} players={players} compact isAdmin={false}/></section>
        </>}
        {page==='leaderboard'&&<><Intro eyebrow="THE RACE FOR THE TOP" title="Leaderboard." description="Your four highest Stableford scores are all that matter. Play whenever you like." action={<div className="intro-badge"><Trophy size={20}/><div><strong>BEST FOUR</strong><span>NET STABLEFORD</span></div></div>}/><div className="leaderboard-meta"><span><span className="green-indicator"/>{ranking.filter(p=>p.qualified).length} qualified</span><span>{rounds.length} total rounds recorded</span><span>Updated automatically</span></div><section className="panel full-board"><Leaderboard rows={ranking} openPlayer={openPlayer}/><div className="panel-footer"><ShieldCheck size={15}/> Players with fewer than 4 rounds appear provisionally. Equal best-four scores are decided by comparing the highest counting round, then the next-highest, and so on. Identical top fours share their rank.</div></section></>}
        {page==='rounds'&&<><Intro eyebrow="EVERY SHOT HAS A STORY" title="Round history." description="Every recorded round, course difficulty and playing handicap in one place." action={<button className="button button-secondary" onClick={exportRounds}><Download size={17}/> Export CSV</button>}/><section className="panel history-panel"><div className="history-controls"><div className="search-box"><Search size={17}/><input type="search" aria-label="Search rounds" placeholder="Search player, course or date…" value={search} onChange={e=>setSearch(e.target.value)}/></div><select aria-label="Filter player" value={filterPlayer} onChange={e=>setFilterPlayer(e.target.value)}><option value="all">All players</option>{players.map(p=><option value={p.id} key={p.id}>{p.name}</option>)}</select><span className="result-count">{filteredRounds.length} {filteredRounds.length===1?'round':'rounds'}</span></div><RoundTable rounds={filteredRounds} players={players} isAdmin={isAdmin} onEdit={r=>{setEditingRound(r);setDialog('round')}} onDelete={deleteRound}/></section></>}
        {page==='players'&&<><Intro eyebrow="THE FIELD" title="Meet the players." description="Eight spots. Unlimited rounds. Everyone has a shot at the top."/ ><div className="players-grid">{ranking.slice().sort((a,b)=>a.display_order-b.display_order).map(p=><button className="player-card" key={p.id} onClick={()=>openPlayer(p.id)}><div className="player-card-top"><Avatar player={p} size="lg"/><span className="player-card-number">#{String(p.display_order).padStart(2,'0')}</span></div><h3>{p.name}</h3><StatusPill qualified={p.qualified} played={p.played}/><div className="player-card-metrics"><div><span>BEST FOUR</span><strong>{p.bestFour||'—'}</strong></div><div><span>ROUNDS</span><strong>{p.played}</strong></div><div><span>BEST ROUND</span><strong>{p.personalBest??'—'}</strong></div></div><div className="player-card-bottom">View profile <ArrowUpRight size={16}/></div></button>)}</div>{isAdmin&&<div className="admin-player-note"><Settings2 size={17}/> To change a player's name, open their profile and select Edit player.</div>}</>}
        {page==='player-detail'&&viewPlayer&&<><button className="back-link" onClick={()=>navigate('players')}><ArrowLeft size={17}/> All players</button><div className="profile-header"><Avatar player={viewPlayer} size="xl"/><div className="profile-title"><span className="eyebrow">PLAYER PROFILE · SLOT {String(viewPlayer.display_order).padStart(2,'0')}</span><h1>{viewPlayer.name}</h1><StatusPill qualified={viewPlayer.qualified} played={viewPlayer.played}/></div>{isAdmin&&<button className="button button-secondary" onClick={()=>{setEditingPlayer(viewPlayer);setDialog('player')}}><Pencil size={16}/> Edit player</button>}</div><div className="profile-stats"><StatCard label="BEST FOUR TOTAL" value={viewPlayer.bestFour||'—'} meta="Leaderboard points" icon={Trophy} accent/><StatCard label="ROUNDS PLAYED" value={viewPlayer.played} meta="All recorded attempts" icon={Target}/><StatCard label="ROUND AVERAGE" value={viewPlayer.played?number(viewPlayer.average):'—'} meta="Stableford points" icon={BarChart3}/><StatCard label="PERSONAL BEST" value={viewPlayer.personalBest??'—'} meta="Best single round" icon={Award}/></div><div className="profile-layout"><section className="panel profile-graph-panel"><div className="panel-header"><div><span className="eyebrow">PLAYER FORM</span><h2>Score progression</h2></div></div><ScoreGraph rows={viewPlayer.rounds}/></section><section className="panel profile-best-panel"><div className="panel-header"><div><span className="eyebrow">THE MONEY ROUNDS</span><h2>Counting scores</h2></div></div><div className="profile-score-list">{Array.from({length:4},(_,i)=><div key={i}><span>ROUND {String(i+1).padStart(2,'0')}</span><strong>{viewPlayer.bestScores[i]??'—'}</strong></div>)}</div><div className="profile-total"><span>COMBINED TOTAL</span><strong>{viewPlayer.bestFour}</strong></div></section></div><section className="panel recent-panel"><div className="panel-header"><div><span className="eyebrow">THE SCORECARD</span><h2>All {viewPlayer.name}'s rounds</h2></div></div><RoundTable rounds={viewPlayer.rounds} players={players} isAdmin={isAdmin} onEdit={r=>{setEditingRound(r);setDialog('round')}} onDelete={deleteRound}/></section></>}
        {page==='courses'&&<><Intro eyebrow="WHERE IT ALL HAPPENED" title="Courses played." description="From iconic links to championship layouts — see where your league has played."/><div className="course-summary"><span><Flag size={16}/> {courses.length} unique courses</span><span><Target size={16}/> {rounds.length} total visits</span><span><Gauge size={16}/> Ratings are informational</span></div><div className="course-grid">{courses.map((c,i)=><div className="course-card" key={c.name}><div className="course-card-top"><span className="course-mark"><FlagTriangleRight size={22}/></span><span className="course-index">COURSE {String(i+1).padStart(2,'0')}</span></div><h3>{c.name}</h3><div className="course-stats"><div><span>ROUNDS</span><strong>{c.count}</strong></div><div><span>AVG POINTS</span><strong>{number(c.sum/c.count)}</strong></div><div><span>DIFFICULTY</span><strong>{c.ratingCount?number(c.ratingSum/c.ratingCount):'—'}</strong></div></div><div className="course-bottom"><span>Highest Stableford</span><strong>{c.topScore} pts</strong></div></div>)}{courses.length===0&&<div className="panel empty-state">Courses appear here as rounds are entered.</div>}</div></>}
        {page==='rules'&&<><Intro eyebrow="THE FORMAT" title="The rules of play." description="A flexible league for golfers who just want to play, compete and improve."/><div className="rules-layout"><section className="panel rule-main"><div className="rule-banner"><Trophy size={31}/><div><span>THE CHAMPIONSHIP FORMAT</span><h2>Best 4 Stableford</h2><p>Play as often as you like. Your highest four net Stableford totals decide your place in the league.</p></div></div><div className="rules-list">{[
          ['01','Play on your schedule','There is no set season end, no weekly attendance requirement, and no limit on the number of rounds you may record.'],
          ['02','Declare every counting attempt','Before a round begins, declare it as a league attempt. Record the final score even if it was a poor round; no selective submission.'],
          ['03','Best four automatically count','Your four highest Stableford totals are summed. You need at least four recorded rounds to qualify for the ranked leaderboard.'],
          ['04','Use net Stableford','Award 0 for net double bogey or worse, 1 for bogey, 2 for par, 3 for birdie, 4 for eagle and 5 for albatross.'],
          ['05','Record the handicap you actually used','Enter your playing handicap for that particular round. Older rounds preserve their original handicap when your current handicap changes.'],
          ['06','Record the course and its difficulty','Enter the course name and its reported difficulty or course rating for every round. The rating is displayed, not used to alter Stableford points.'],
          ['07','Agree simulator settings','Use the same agreed tee and simulator settings where practical. No mulligans or voluntary restarts. Resolve genuine simulator faults with the organiser.'],
          ['08','Resolve ties fairly','Compare best-four totals first, then highest counting round, second-highest, third and fourth. Completely identical top-four scores share the placing.'],
        ].map(([n,title,desc])=><div className="rule-item" key={n}><span className="rule-index">{n}</span><div><h3>{title}</h3><p>{desc}</p></div></div>)}</div></section><aside className="rules-side"><div className="rules-side-block"><span className="eyebrow">STANDARD STABLEFORD</span><h3>How points work</h3>{[['Net double bogey +','0'],['Net bogey','1'],['Net par','2'],['Net birdie','3'],['Net eagle','4'],['Net albatross','5']].map(([s,v])=><div className="points-rule" key={s}><span>{s}</span><strong>{v}</strong></div>)}<p>All results are after applying handicap strokes.</p></div><div className="rules-side-callout"><Clock3 size={22}/><h3>No clock. No pressure.</h3><p>There's no expiry date on the league. Every new round is another chance to improve your best four.</p></div></aside></div></>}
        </>}
        <footer className="site-footer"><div><FlagTriangleRight size={17}/> <strong>{LEAGUE.name}</strong><span>·</span> THE SIM SERIES</div><span>PLAY YOUR GAME. OWN YOUR SCORE.</span><span>{isConfigured?'Powered by Supabase':'Sample data · Preview mode'}</span></footer>
      </main>
    </div>
    {dialog==='auth'&&<AuthDialog close={()=>setDialog(null)} notify={notify}/>}
    {dialog==='setup'&&<SetupDialog close={()=>setDialog(null)}/>}
    {dialog==='round'&&isAdmin&&<RoundDialog close={()=>{setDialog(null);setEditingRound(null)}} original={editingRound} save={saveRound} players={players}/>}
    {dialog==='player'&&isAdmin&&editingPlayer&&<PlayerDialog player={editingPlayer} close={()=>{setDialog(null);setEditingPlayer(null)}} save={savePlayer}/>}
    <Toast message={toast} onClose={()=>setToast('')}/>
  </div>;
}
