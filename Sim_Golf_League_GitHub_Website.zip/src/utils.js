export const formatDate = (value) => value
  ? new Date(`${value}T12:00:00`).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
  : '—';

export const number = (value, digits = 1) => Number(value).toFixed(digits);
export const initials = (name) => (name || '?').trim().split(/\s+/).slice(0, 2).map(s => s[0]).join('').toUpperCase();

export function standings(players, rounds) {
  const list = players.map(player => {
    const playerRounds = rounds.filter(r => r.player_id === player.id);
    const scores = playerRounds.map(r => Number(r.stableford_points)).sort((a, b) => b - a);
    const bestScores = scores.slice(0, 4);
    const bestFour = bestScores.reduce((sum, pts) => sum + pts, 0);
    const qualified = scores.length >= 4;
    return {
      ...player, rounds: playerRounds, played: scores.length,
      bestScores, bestFour, qualified,
      average: scores.length ? scores.reduce((s, p) => s + p, 0) / scores.length : 0,
      personalBest: scores.length ? scores[0] : null,
    };
  });
  list.sort((a, b) => {
    if (a.qualified !== b.qualified) return Number(b.qualified) - Number(a.qualified);
    if (a.qualified && b.qualified && b.bestFour !== a.bestFour) return b.bestFour - a.bestFour;
    if (a.qualified && b.qualified) {
      for (let i = 0; i < 4; i++) if (b.bestScores[i] !== a.bestScores[i]) return b.bestScores[i] - a.bestScores[i];
    }
    if (!a.qualified && !b.qualified) return b.played - a.played || b.bestFour - a.bestFour;
    return a.display_order - b.display_order;
  });
  let lastFingerprint = null;
  let lastRank = null;
  return list.map((player, i) => {
    if (!player.qualified) return { ...player, rank: null };
    const fingerprint = `${player.bestFour}-${player.bestScores.join('-')}`;
    const rank = fingerprint === lastFingerprint ? lastRank : i + 1;
    lastFingerprint = fingerprint;
    lastRank = rank;
    return { ...player, rank };
  });
}
export const toCSV = (rows) => {
  const headers = ['Date','Player','Course','Difficulty rating','Handicap used','Stableford points','Notes'];
  const csvSafe = v => `"${String(v ?? '').replaceAll('"','""')}"`;
  return [headers.join(','), ...rows.map(r => [r.played_on,r.playerName,r.course,r.difficulty_rating,r.handicap_used,r.stableford_points,r.notes].map(csvSafe).join(','))].join('\r\n');
};
