// Transparent sample scores for the unconfigured preview. Never written to Supabase.
const names = ['James', 'Tom', 'Dave', 'Ben', 'Chris', 'Alex', 'Sam', 'Jordan'];
export const demoPlayers = names.map((name, i) => ({ id: `demo-player-${i + 1}`, name, display_order: i + 1 }));
const courses = [
  ['St Andrews – Old Course', 73.1], ['Pebble Beach', 75.5],
  ['Royal Birkdale', 74.3], ['Augusta National', 76.2],
  ['Carnoustie', 75.0], ['Whistling Straits', 76.1],
  ['Pinehurst No. 2', 74.9], ['Torrey Pines South', 75.6],
];
const scoreArrays = [
  [36, 42, 39, 43, 38, 41, 32], [37, 42, 38, 40, 39, 37, 35, 34],
  [40, 39, 38, 37, 32], [35, 39, 38, 36, 37, 34],
  [42, 39], [35, 40, 34, 38, 36, 39],
  [34, 35, 37, 33], [38, 35, 37],
];
const handicaps = [12.5, 9.2, 16.1, 19.0, 7.4, 14.8, 21.3, 11.0];
const all = [];
scoreArrays.forEach((scores, p) => {
  scores.forEach((points, index) => {
    const dt = new Date(Date.UTC(2026, 8, 8 + index * 8 + p * 2));
    const [course, difficulty_rating] = courses[(index + p * 2) % courses.length];
    all.push({
      id: `demo-${p}-${index}`,
      player_id: demoPlayers[p].id,
      played_on: dt.toISOString().slice(0, 10),
      course, difficulty_rating,
      handicap_used: handicaps[p] + Math.round(index / 3) * 0.2,
      stableford_points: points,
      notes: '',
    });
  });
});
export const demoRounds = all.sort((a, b) => b.played_on.localeCompare(a.played_on));
