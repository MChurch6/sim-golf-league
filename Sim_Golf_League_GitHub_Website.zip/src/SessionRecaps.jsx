import React, { useEffect, useRef } from 'react';

const sessions = [
  {
    id: '2026-11-22', date: '22 November 2026', course: 'JCB Golf and Country Club',
    tees: 'Yellow tees · Par 72 · 6,599 yards',
    source: 'https://www.jcb.com/en-GB/explore/engage/jcb-golf-and-country-club/',
    overview: 'Robin Hiseman’s Staffordshire course features an island-green par 3 at the 17th, which played 205 yards from the simulator’s Yellow tees.',
    results: 'Ham won with 31 Stableford points, ahead of Zak (30), Chig (29), Dob (24), debutant Coats (21) and Church23 (19). Zak had the lowest gross score with 93.',
    highlights: [
      'Ham blanked the island-green 17th, then parred the last for three points to win by one.',
      'Zak birdied the par-4 12th. Chig and Coats both parred the island-green 17th.',
      'Coats took 22 strokes on the par-5 13th, then picked up eight points over the final four holes.',
    ],
    snapshot: 'Zak 66 · Chig 63 · Church23 60',
    bestHole: 'Chig · 10th · Gross par on the par 5 · 5 Stableford points',
    birdies: ['Zak · 12th · 3 on a par 4'],
    eagles: [],
  },
  {
    id: '2026-11-08', date: '8 November 2026', course: 'Clear Creek Tahoe',
    tees: 'Silver tees · Par 71 · 6,462 yards',
    source: 'https://clearcreektahoe.com/golf/',
    overview: 'Bill Coore and Ben Crenshaw designed this Nevada mountain course. From the simulator’s Silver tees, the 17th played just 131 yards, while the par-5 13th stretched to 573 yards.',
    results: 'Church23 won the opener with 41 Stableford points, ahead of Zak (36), Chig (34), Aaron (32), Dob (26) and Ham (21). Zak shot the lowest gross score with 82.',
    highlights: [
      'Church23 birdied the par-3 17th for four points. Aaron also earned four points for his birdie at the par-4 14th.',
      'Chig earned five Stableford points on each of the par-5 1st and 6th with gross pars.',
      'Church23 took 11 strokes and scored zero at the 6th, then picked up nine points over the next three holes.',
    ],
    snapshot: 'Church23 41 · Zak 36 · Chig 34',
    bestHole: 'Chig · 1st and 6th · Gross pars on both par 5s · 5 Stableford points each',
    birdies: ['Church23 · 17th · 2 on a par 3', 'Aaron · 14th · 3 on a par 4'],
    eagles: [],
  },
];

const orderedSessions = [...sessions].sort((a, b) => b.id.localeCompare(a.id));
const latest = orderedSessions[0];

export function LatestRoundReport({ onOpen, home = false }) {
  if (!latest) return null;

  const link = <a className="latest-report-link" href={'#recap-' + latest.id} onClick={event => {
    event.preventDefault();
    onOpen(latest.id);
  }}>View latest round report <span aria-hidden="true">↗</span></a>;
  const label = <span>{latest.course} · {latest.date}</span>;

  return home
    ? <section className="panel latest-report-home">
        <h2>Session recap</h2>
        <p>{label}</p>
        {link}
      </section>
    : <aside className="latest-report-banner" aria-label="Latest round report">{link}{label}</aside>;
}

export default function SessionRecaps({ openReport }) {
  const activeReport = useRef(null);

  useEffect(() => {
    if (!openReport || !activeReport.current) return;
    const report = activeReport.current;
    report.open = true;
    report.querySelector('summary').focus({ preventScroll: true });
    report.scrollIntoView({ block: 'start', behavior: 'instant' });
  }, [openReport]);

  return <section className="session-recaps" aria-labelledby="session-recaps-heading">
    <h2 id="session-recaps-heading">Session recaps</h2>
    {orderedSessions.map(session => <details className="panel session-recap" key={session.id} id={'recap-' + session.id} ref={session.id === openReport ? activeReport : null}>
      <summary>
        <strong>{session.course}</strong>
        <span>{session.date} · {session.tees}</span>
      </summary>
      <div className="session-body">
        <p>{session.overview} <a href={session.source}>Course overview</a></p>
        <p>{session.results}</p>
        <h3>Scorecard highlights</h3>
        <ul>{session.highlights.map(highlight => <li key={highlight}>{highlight}</li>)}</ul>
        <h3>League snapshot</h3>
        <p>{session.snapshot}. Provisional totals after this session. Four rounds are needed to qualify.</p>
        <h3>Highest Stableford points on a hole</h3>
        <p>{session.bestHole}</p>
      </div>
    </details>)}
    <section className="panel session-tracker" aria-labelledby="birdie-tracker-heading">
      <h3 id="birdie-tracker-heading">Birdie and eagle tracker</h3>
      {orderedSessions.map(session => <div className="tracker-session" key={session.date}>
        <h4>{session.course}</h4>
        <p><strong>Gross birdies</strong></p>
        <ul>{session.birdies.map(birdie => <li key={birdie}>{birdie}</li>)}</ul>
        <p><strong>Gross eagles</strong> · {session.eagles.length ? session.eagles.join(', ') : 'None recorded'}</p>
      </div>)}
    </section>
  </section>;
}
