import React, { useState } from 'react';
import { formatDate } from './utils.js';
import { hasRecordedEagles, scoringTotals } from './SessionRecaps.jsx';

export default function PlayerComparison({ players }) {
  const [leftId, setLeftId] = useState('');
  const [rightId, setRightId] = useState('');
  const left = players.find(player => player.id === leftId) ?? players[0];
  const right = players.find(player => player.id === rightId && player.id !== left?.id)
    ?? players.find(player => player.id !== left?.id);
  if (!left || !right) return null;

  const cards = [
    { label: 'First player', player: left, other: right, select: setLeftId },
    { label: 'Second player', player: right, other: left, select: setRightId },
  ];

  return <details className="panel player-comparison">
    <summary>Compare players</summary>
    <div className="comparison-grid">
      {cards.map(({ label, player, other, select }) => {
        const totals = scoringTotals.get(player.display_order);
        const recent = [...player.rounds].sort((a, b) => b.played_on.localeCompare(a.played_on)).slice(0, 4).reverse();
        return <section className="comparison-player" key={label}>
          <label>{label}
            <select value={player.id} onChange={event => select(event.target.value)}>
              {players.map(option => <option key={option.id} value={option.id} disabled={option.id === other.id}>{option.name}</option>)}
            </select>
          </label>
          <dl>
            <div><dt>Rounds played</dt><dd>{player.played}</dd></div>
            <div><dt>Best-four total</dt><dd>{player.played ? player.bestFour : '—'}</dd></div>
            <div><dt>Average points</dt><dd>{player.played ? player.average.toFixed(1) : '—'}</dd></div>
            <div><dt>Gross birdies</dt><dd>{totals?.birdies ?? 0}</dd></div>
            {hasRecordedEagles && <div><dt>Gross eagles</dt><dd>{totals?.eagles ?? 0}</dd></div>}
          </dl>
          <h3>Recent form</h3>
          {recent.length ? <ol className="comparison-form">
            {recent.map(round => <li key={round.id}><span>{formatDate(round.played_on)}</span><strong>{round.stableford_points} pts</strong></li>)}
          </ol> : <p>No rounds yet.</p>}
        </section>;
      })}
    </div>
  </details>;
}
