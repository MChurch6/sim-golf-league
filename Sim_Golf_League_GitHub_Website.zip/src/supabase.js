import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
export const isConfigured = Boolean(url && anonKey && url.startsWith('https://') && !url.includes('YOUR_PROJECT') && !anonKey.includes('YOUR_PUBLIC'));
export const supabase = isConfigured ? createClient(url, anonKey, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
}) : null;
