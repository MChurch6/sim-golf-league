/** Edit the public-facing branding here. No restart of the database required. */
export const LEAGUE = {
  name: 'Handforth Winter League',
  tagline: 'WINTER LEAGUE',
  season: 'THE OPEN LEAGUE',
  description: 'Any course. Any week. Your best four count.',
  minRounds: 4,
  maxPlayers: 8,
};
