/** Edit the public-facing branding here. No restart of the database required. */
export const LEAGUE = {
  name: 'THE CLUBHOUSE',
  tagline: 'THE SIM SERIES',
  season: 'THE OPEN LEAGUE',
  description: 'Any course. Any week. Your best four count.',
  minRounds: 4,
  maxPlayers: 8,
};
