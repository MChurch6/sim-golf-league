# THE CLUBHOUSE — Sim Golf League

A polished, mobile-friendly golf simulator league website. **Eight players, no season end date, unlimited rounds, a best-four net Stableford leaderboard, and a securely restricted score-entry interface.**

![Site features](https://img.shields.io/badge/Leaderboard-Best%204-9cc46f) ![Hosting](https://img.shields.io/badge/Hosting-GitHub%20Pages-222) ![Database](https://img.shields.io/badge/Database-Supabase-3dbb80)

## What works

- Public read-only leaderboard with best four scores, provisional players, tied scores and qualification at four rounds.
- Unlimited rounds, any date and any course — each records its own **handicap used**, **course**, **course difficulty rating**, **Stableford points**, and optional notes.
- Public player profiles, performance graph, complete round history, course statistics, search/filter, and CSV export.
- Secure administrator email/password login. Only the administrator can create, edit or delete rounds, or rename players. Security is enforced by **Supabase Row Level Security (RLS)** on the server.
- Automatic refresh via Supabase Realtime plus a 60-second fallback, with manual refresh.
- Responsive desktop and phone layout.
- A demonstration mode with clearly marked **sample data** before Supabase is configured. Sample data is not shared or saved.

## Go live — step by step

### 1. Create the database (Supabase)

1. Create a project at [supabase.com](https://supabase.com).
2. In **SQL Editor**, create a new query, paste the entire contents of [`supabase/schema.sql`](supabase/schema.sql), and **Run** it. This creates exactly eight placeholder players, the score table and the read/write security rules.
3. In **Authentication → Users**, use **Add user** to add **your own email and password**. You can turn off public sign-ups under **Authentication → Providers → Email** if you want only your account to exist.
4. To give your user administrator rights, go back to SQL Editor and run the following with your actual email address:

```sql
insert into public.league_admins (user_id)
select id from auth.users where email = 'YOUR_EMAIL@example.com'
on conflict (user_id) do nothing;
```

The query should affect **one row**. If it affects zero rows, check the email address and confirm your user exists in Authentication.

5. Copy your **Project URL** and **anon/public (publishable) key** from Supabase **Project Settings → API**. Never use the `service_role`/secret key in the website.

### 2. Create a GitHub repository

1. Create a **new public repository**, such as `sim-golf-league` (keep your existing repositories unchanged).
2. Upload all the files from this project ZIP, including the hidden `.github/workflows/deploy.yml` folder. The project files must be at the **root** of the repository, not inside an extra nested folder.
3. Go to **Settings → Secrets and variables → Actions → Variables**. Create:

   | Variable | Value |
   |---|---|
   | `VITE_SUPABASE_URL` | Your Supabase Project URL |
   | `VITE_SUPABASE_ANON_KEY` | Your Supabase public/anon key |

   These values are intentionally publicly usable, and are protected by RLS. **Do not supply a private service-role key.**

4. Go to **Settings → Pages → Build and deployment → Source**, and select **GitHub Actions**.
5. In the **Actions** tab, run **Deploy golf league to GitHub Pages** (or push a commit to `main`). The included workflow builds and publishes the website.

Your address will look like:

`https://YOUR_GITHUB_USERNAME.github.io/sim-golf-league/`

*(If you use a custom domain or a `<username>.github.io` repository, update `VITE_BASE_PATH` in the GitHub workflow to `/`.)*

### 3. Enter scores

1. Open the website and select **Admin login**.
2. Sign in using the Supabase user you created in Step 1.
3. Open **Players**, select a player's profile, then **Edit player** to replace placeholder names.
4. Select **Add round**, enter the player, date, course, playing handicap, difficulty rating and Stableford score, then save.
5. Share the website link with your friends. They can see live scores **without an account**, but cannot change them.

## Run locally

Install [Node.js](https://nodejs.org/) version 20 or later, then:

```bash
npm install
cp .env.example .env
# edit .env with your Supabase URL and public anon key
npm run dev
```

Run `npm test` to verify the ranking logic.

Open the local address Vite shows (typically `http://localhost:5173`). You can omit `.env` to run with demo scores while checking the design.

To build a deployable static website locally, run `npm run build` (output: `dist/`).

## Competition rules

- **No end date, no mandatory weeks, no maximum number of attempts.**
- Declare all league attempts before starting, and record them regardless of the result.
- Stableford points use the player's playing handicap for **that specific round**.
- Best **four** points totals are combined to determine the leaderboard. A player needs **four completed rounds** to qualify.
- Tie-break: highest counting score, next-highest, third, fourth. Completely identical counting scores share the rank.
- Course rating is **recorded for context only**; it does **not** adjust Stableford points. Make sure everyone agrees how to enter this metric (for example, actual course rating rather than slope rating or an arbitrary simulator difficulty setting).
- Agree on tees and simulator settings, mulligans and equipment-failure handling before the league starts.

## Admin access and security

The public site uses the Supabase **publishable/anon key**. This key is not a password and may be visible in the site's JavaScript. RLS allows anonymous and signed-in visitors to **read** players and rounds; insert/update/delete operations require an authenticated user whose ID is in the private `league_admins` table. This is verified at the database, so bypassing the website's user interface does not permit edits.

- Do **not** replace the anon key with a secret or service-role key.
- Do **not** open write policies to `anon` or to all `authenticated` users.
- Disable public self-signup if you do not need it.
- Enable MFA on your Supabase account if supported by your auth setup.

## Project layout

```text
sim-golf-league/
├── .github/workflows/deploy.yml  # automatic GitHub Pages build
├── .env.example                  # connection configuration
├── index.html
├── package.json
├── public/favicon.svg
├── src/
│   ├── App.jsx                   # all screens + admin forms
│   ├── styles.css                 # visual design
│   ├── config.js                  # club name and format labels
│   ├── supabase.js                # public client
│   ├── data.js                    # sample scores for preview mode
│   ├── utils.js                   # rankings and CSV export
│   └── main.jsx
├── supabase/schema.sql           # tables, data, admin security
└── vite.config.js                # GitHub Pages path handling
```

## Customize

- Change the public name and tagline in `src/config.js`.
- Change colors in `src/styles.css`.
- To clear the preview, connect Supabase: your published site then starts with eight placeholder players and **no fake rounds**.
- Download or back up real scores anytime from **Round history → Export CSV**.

## Troubleshooting

**Website says “Preview Mode”.** Either the two environment variables are unset or invalid, or the site wasn't rebuilt after adding them. Add variables in GitHub Actions and rerun the deployment workflow.

**You can sign in but can't add scores.** Add your Supabase Authentication user ID to `league_admins` using the SQL above, then sign out and in again.

**Scores are blank or don't update.** Inspect the browser's console, check Supabase project's URL/key, confirm the `schema.sql` query ran, and check that your Supabase project is active. The site polls every 60 seconds even if Realtime is unavailable.

**Not loading at `username.github.io/repo/`.** Confirm the workflow has `VITE_BASE_PATH: /${{ github.event.repository.name }}/`, and the Pages Source is set to GitHub Actions.

## Status

**The project is fully implemented but is not published or connected to your own Supabase account yet.** GitHub Pages hosting, database creation, admin user creation and setting credentials require your own account setup. The repository files and deployment workflow are provided in the download.
